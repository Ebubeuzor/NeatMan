<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>Your transaction failed</div>
</body>
</html><?php /**PATH C:\Users\Ebubeuzor\Desktop\code2\Foxworld\resources\views/Failed.blade.php ENDPATH**/ ?>